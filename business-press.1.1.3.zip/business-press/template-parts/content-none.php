<div class="content-first">

	<div class="content-second">
		<h3 class="the-title"><?php esc_attr_e( 'Posts Not Found','business-press' ); ?></h3>
	</div>
	
	<div class="content-third">
		
		<p><?php esc_attr_e( 'Maybe try a search?','business-press' ); ?></p>
		
		<?php get_search_form(); ?>
		
	</div>	
	
</div>