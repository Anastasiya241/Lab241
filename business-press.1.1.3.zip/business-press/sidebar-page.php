<div class="col-md-4">
	<div class="right-content" >
		<?php
		if( is_active_sidebar( 'business_press_sidebar_page' ) )
		{
			dynamic_sidebar( 'business_press_sidebar_page' );
		}
		?>
	</div>
</div>