<div class="col-md-4">
	<div class="right-content" >
		<?php
		if( is_active_sidebar( 'business_press_sidebar_woo' ) )
		{
			dynamic_sidebar( 'business_press_sidebar_woo' );
		}
		?>
	</div>
</div>