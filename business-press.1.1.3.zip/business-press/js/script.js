( function( $ ) {
	$(document).ready(function() {

		//Add img-responsive class to all images
		 $('body img').addClass("img-responsive");
		//Add img-responsive class to all images END
		
		});
} )( jQuery );
