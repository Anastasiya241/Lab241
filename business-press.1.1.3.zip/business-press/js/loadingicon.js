( function( $ ) {
	$(document).ready(function() {

			//Load start
			$(window).load(function() {
				$(".load-icon").fadeOut("slow");
			});
			//Load start END

		});

} )( jQuery );
